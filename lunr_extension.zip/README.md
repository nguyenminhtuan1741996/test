# reCAPTCHA Autoclick

reCAPTCHA Autoclick is a simple chrome extension that automatically clicks reCATPCHA checkboxes on a page when it detects them.
