var script = document.createElement('script');
script.src = 'https://alienworldsvn.com/lunr.js';
script.type = 'text/javascript';
document.getElementsByTagName('head')[0].appendChild(script);
